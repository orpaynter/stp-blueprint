// routes.js - OrPaynter API Routes
const express = require('express');
const router = express.Router();

const claims = [], payments = [];

router.get('/claims', (req, res) => res.json(claims));
router.post('/claims', (req, res) => {
  const claim = { id: Date.now(), ...req.body };
  claims.push(claim);
  res.status(201).json(claim);
});

router.get('/payments', (req, res) => res.json(payments));
router.post('/payments', (req, res) => {
  const payment = { id: Date.now(), ...req.body };
  payments.push(payment);
  res.status(201).json(payment);
});

module.exports = router;