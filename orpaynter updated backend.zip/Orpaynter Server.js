// server.js - OrPaynter API Bootstrapping
const express = require('express');
const config = require('./config');
const apiRoutes = require('./routes');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

app.get('/health', (req, res) => {
  res.send({ status: 'OK', uptime: process.uptime() });
});

app.get('/', (req, res) => {
  res.send('OrPaynter API is running');
});

app.use('/api', apiRoutes);

app.get('/config-check', (req, res) => {
  res.json({
    databaseUrl: config.databaseUrl ? '✅' : '❌',
    sendgridApiKey: config.sendgridApiKey ? '✅' : '❌',
    stripeSecretKey: config.stripeSecretKey ? '✅' : '❌',
    openweatherApiKey: config.openweatherApiKey ? '✅' : '❌',
    googleCalendarCredentials: config.googleCalendarCredentials ? '✅' : '❌',
    twilioAuthToken: config.twilioAuthToken ? '✅' : '❌'
  });
});

app.listen(PORT, () => {
  console.log(`🚀 OrPaynter API running at http://localhost:${PORT}`);
});