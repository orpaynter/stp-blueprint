// config.js - OrPaynter Debug Config Logger
require('dotenv').config();

const config = {
  databaseUrl: process.env.DATABASE_URL,
  sendgridApiKey: process.env.SENDGRID_API_KEY,
  stripeSecretKey: process.env.STRIPE_SECRET_KEY,
  openweatherApiKey: process.env.OPENWEATHER_API_KEY,
  googleCalendarCredentials: process.env.GOOGLE_CALENDAR_CREDENTIALS,
  twilioAuthToken: process.env.TWILIO_AUTH_TOKEN
};

console.log("[DEBUG] Loaded Configuration:");
Object.entries(config).forEach(([key, value]) => {
  console.log(`[DEBUG] ${key}: ${value ? 'Loaded' : 'Missing'}`);
});

module.exports = config;